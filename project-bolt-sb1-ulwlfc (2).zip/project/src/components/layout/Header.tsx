import React from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap, Menu, X, User, Home, Archive } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { user } = useAuth();

  return (
    <header className="bg-indigo-600 text-white">
      <nav className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Link to="/" className="flex items-center space-x-2">
              <GraduationCap className="h-8 w-8" />
              <span className="text-xl font-bold">PolytechAcademia</span>
            </Link>
            <Link to="/" className="hidden md:flex items-center space-x-2 hover:text-indigo-200">
              <Home className="h-5 w-5" />
              <span>Accueil</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/departments" className="hover:text-indigo-200">Départements</Link>
            <Link to="/resources" className="hover:text-indigo-200">Ressources</Link>
            <Link to="/alumni" className="hover:text-indigo-200">Anciens Étudiants</Link>
            <Link to="/archives" className="hover:text-indigo-200 flex items-center space-x-2">
              <Archive className="h-5 w-5" />
              <span>Archives Académiques</span>
            </Link>
            {user ? (
              <Link 
                to="/profile" 
                className="flex items-center space-x-2 bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100"
              >
                <User className="h-4 w-4" />
                <span>{user.fullName.split(' ')[0]}</span>
              </Link>
            ) : (
              <Link to="/login" className="bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100">
                Connexion
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <Link to="/" className="flex items-center space-x-2 hover:text-indigo-200">
              <Home className="h-5 w-5" />
              <span>Accueil</span>
            </Link>
            <Link to="/departments" className="block hover:text-indigo-200">Départements</Link>
            <Link to="/resources" className="block hover:text-indigo-200">Ressources</Link>
            <Link to="/alumni" className="block hover:text-indigo-200">Anciens Étudiants</Link>
            <Link to="/archives" className="block hover:text-indigo-200 flex items-center space-x-2">
              <Archive className="h-5 w-5" />
              <span>Archives Académiques</span>
            </Link>
            {user ? (
              <Link 
                to="/profile" 
                className="block bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 text-center"
              >
                Mon Profil
              </Link>
            ) : (
              <Link to="/login" className="block bg-white text-indigo-600 px-4 py-2 rounded-md hover:bg-indigo-100 text-center">
                Connexion
              </Link>
            )}
          </div>
        )}
      </nav>
    </header>
  );
}
