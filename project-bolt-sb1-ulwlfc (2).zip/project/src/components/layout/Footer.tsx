import React from 'react';
import { Mail, Phone, MapPin, Youtube, Linkedin, MessageCircle } from 'lucide-react';

export function Footer() {
  const socialLinks = [
    {
      name: 'YouTube',
      icon: <Youtube className="h-6 w-6" />,
      url: 'https://youtube.com/@fulltutotech1015?si=pwf3nYN94dOW8Ixu',
      color: 'hover:text-red-600'
    },
    {
      name: 'LinkedIn',
      icon: <Linkedin className="h-6 w-6" />,
      url: 'https://www.linkedin.com/in/eliel-ngoy-627920315?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
      color: 'hover:text-blue-600'
    },
    {
      name: 'WhatsApp',
      icon: <MessageCircle className="h-6 w-6" />,
      url: 'https://wa.me/243977417619',
      color: 'hover:text-green-600'
    }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">PolytechAcademia</h3>
            <p className="text-gray-400">
              Plateforme éducative dédiée aux étudiants de la faculté polytechnique.
            </p>
            {/* Social Media Icons */}
            <div className="mt-6 flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`transform transition-all duration-300 ${social.color} hover:scale-110`}
                  aria-label={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 group">
                <div className="p-2 rounded-full bg-gray-800 group-hover:bg-indigo-600 transition-colors duration-300">
                  <Mail className="h-5 w-5" />
                </div>
                <span className="group-hover:text-indigo-400 transition-colors duration-300">
                  contact@polytechacademia.com
                </span>
              </div>
              <div className="flex items-center space-x-3 group">
                <div className="p-2 rounded-full bg-gray-800 group-hover:bg-indigo-600 transition-colors duration-300">
                  <Phone className="h-5 w-5" />
                </div>
                <span className="group-hover:text-indigo-400 transition-colors duration-300">
                  +243 977417619
                </span>
              </div>
              <div className="flex items-center space-x-3 group">
                <div className="p-2 rounded-full bg-gray-800 group-hover:bg-indigo-600 transition-colors duration-300">
                  <MapPin className="h-5 w-5" />
                </div>
                <span className="group-hover:text-indigo-400 transition-colors duration-300">
                  Kolwezi, RD Congo
                </span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Liens Rapides</h3>
            <ul className="space-y-2">
              <li>
                <a href="/about" className="hover:text-indigo-400 transition-colors duration-300 flex items-center space-x-2">
                  <span>À propos</span>
                </a>
              </li>
              <li>
                <a href="/departments" className="hover:text-indigo-400 transition-colors duration-300 flex items-center space-x-2">
                  <span>Départements</span>
                </a>
              </li>
              <li>
                <a href="/resources" className="hover:text-indigo-400 transition-colors duration-300 flex items-center space-x-2">
                  <span>Ressources</span>
                </a>
              </li>
              <li>
                <a href="/contact" className="hover:text-indigo-400 transition-colors duration-300 flex items-center space-x-2">
                  <span>Contact</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            &copy; {new Date().getFullYear()} PolytechAcademia. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}