import React from 'react';
import { Download, FileText, User, Calendar, Award, BookOpen } from 'lucide-react';
import { ArchiveType } from '../../types/archive';

interface ArchiveCardProps {
  archive: ArchiveType;
  onDownload: (id: string) => void;
}

export function ArchiveCard({ archive, onDownload }: ArchiveCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-2">{archive.title}</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            {archive.tags.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        <button
          onClick={() => onDownload(archive.id)}
          className="flex items-center justify-center w-10 h-10 bg-indigo-100 rounded-full text-indigo-600 hover:bg-indigo-200 transition-colors duration-200"
        >
          <Download className="w-5 h-5" />
        </button>
      </div>

      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
        {archive.abstract}
      </p>

      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4" />
          <span>{archive.author}</span>
        </div>
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4" />
          <span>{archive.year}</span>
        </div>
        <div className="flex items-center space-x-2">
          <Award className="w-4 h-4" />
          <span>{archive.supervisor}</span>
        </div>
        <div className="flex items-center space-x-2">
          <BookOpen className="w-4 h-4" />
          <span>{archive.type}</span>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between text-sm text-gray-500">
        <div className="flex items-center space-x-2">
          <FileText className="w-4 h-4" />
          <span>{archive.fileSize}</span>
        </div>
        <span>{archive.downloadCount} téléchargements</span>
      </div>
    </div>
  );
}