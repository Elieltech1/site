import React from 'react';
import { Filter } from 'lucide-react';

interface ArchiveFiltersProps {
  selectedDepartment: string;
  selectedType: string;
  selectedYear: string;
  selectedGrade: string;
  onDepartmentChange: (value: string) => void;
  onTypeChange: (value: string) => void;
  onYearChange: (value: string) => void;
  onGradeChange: (value: string) => void;
}

export function ArchiveFilters({
  selectedDepartment,
  selectedType,
  selectedYear,
  selectedGrade,
  onDepartmentChange,
  onTypeChange,
  onYearChange,
  onGradeChange
}: ArchiveFiltersProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Département</label>
        <select
          value={selectedDepartment}
          onChange={(e) => onDepartmentChange(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          <option value="all">Tous les départements</option>
          <option value="Chimie Industrielle">Chimie Industrielle</option>
          <option value="Électromécanique">Électromécanique</option>
          <option value="Mines">Mines</option>
          <option value="Métallurgie">Métallurgie</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Type de travail</label>
        <select
          value={selectedType}
          onChange={(e) => onTypeChange(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          <option value="all">Tous les types</option>
          <option value="TFC">TFC</option>
          <option value="TFE">TFE</option>
          <option value="Mémoire">Mémoire</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Année</label>
        <select
          value={selectedYear}
          onChange={(e) => onYearChange(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          <option value="all">Toutes les années</option>
          <option value="2023">2023</option>
          <option value="2022">2022</option>
          <option value="2021">2021</option>
          <option value="2020">2020</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Niveau</label>
        <select
          value={selectedGrade}
          onChange={(e) => onGradeChange(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          <option value="all">Tous les niveaux</option>
          <option value="Grade 2">Grade 2</option>
          <option value="Bac 3">Bac 3</option>
        </select>
      </div>
    </div>
  );
}