import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  value: string;
  label: string;
  description: string;
}

export function StatCard({ icon: Icon, value, label, description }: StatCardProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
      <div className="text-indigo-600 mb-4">
        <Icon className="h-8 w-8" />
      </div>
      <div className="text-3xl font-bold text-gray-900 mb-2">{value}</div>
      <div className="font-semibold text-gray-800 mb-2">{label}</div>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
}