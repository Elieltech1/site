import React from 'react';
import { Download, FileText } from 'lucide-react'; // Icône PDF

interface ResourceType {
  id: string;
  title: string;
  type: string;
  description: string;
  department: string;
  promotion: string;
  professor: string;
  size: string;
}

interface ResourceCardProps {
  resource: ResourceType;
  onDownload: (id: string) => void;
}

const additionalResources: ResourceType[] = [
  { id: '1', title: 'Cours Chimie - Introduction à la Chimie', type: 'pdf', description: 'Introduction aux concepts de base en chimie', department: 'chimie', promotion: '2024', professor: 'Prof. Dupont', size: '2MB' },
  { id: '2', title: 'Cours Chimie - Réactions chimiques', type: 'pdf', description: 'Les différents types de réactions chimiques', department: 'chimie', promotion: '2024', professor: 'Prof. Lefevre', size: '3MB' },
  { id: '3', title: 'Cours Chimie - Thermodynamique', type: 'pdf', description: 'Principes de base en thermodynamique appliquée à la chimie', department: 'chimie', promotion: '2024', professor: 'Prof. Moreau', size: '4MB' },
  { id: '4', title: 'Cours Électromécanique - Circuits électriques', type: 'pdf', description: 'Étude des circuits électriques et des composants électroniques', department: 'electromecanique', promotion: '2024', professor: 'Prof. Martin', size: '5MB' },
  // ... autres cours PDF
  { id: '150', title: 'Cours Chimie - Chimie physique avancée', type: 'pdf', description: 'Concepts avancés de la chimie physique', department: 'chimie', promotion: '2024', professor: 'Prof. Martin', size: '6MB' }
];

export function ResourceCard({ resource, onDownload }: ResourceCardProps) {
  const getTypeIcon = () => {
    switch (resource.type) {
      case 'pdf':
        return <FileText className="w-4 h-4 mr-1" />;
      default:
        return <FileText className="w-4 h-4 mr-1" />;
    }
  };

  const getDepartmentName = () => {
    switch (resource.department) {
      case 'chimie':
        return 'Chimie Industrielle';
      case 'electromecanique':
        return 'Électromécanique';
      case 'mines':
        return 'Mines';
      case 'metallurgie':
        return 'Métallurgie';
      default:
        return resource.department;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <div className="p-2 bg-indigo-100 rounded-lg">
              {getTypeIcon()}
            </div>
            <span className="text-sm text-gray-500">{resource.type.toUpperCase()}</span>
          </div>
          <h3 className="text-lg font-semibold mb-2">{resource.title}</h3>
          <p className="text-sm text-gray-600 mb-4">{resource.description}</p>
          <div className="space-y-1">
            <p className="text-sm text-gray-600">
              <span className="font-medium">Département:</span> {getDepartmentName()}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Promotion:</span> {resource.promotion}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Professeur:</span> {resource.professor}
            </p>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Taille:</span> {resource.size}
            </p>
          </div>
        </div>
        <button
          onClick={() => onDownload(resource.id)}
          className="flex items-center justify-center w-10 h-10 bg-indigo-100 rounded-full text-indigo-600 hover:bg-indigo-200 transition-colors duration-200"
        >
          <Download className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

// Composant principal affichant toutes les ressources PDF
export function ResourceList() {
  const handleDownload = (id: string) => {
    // Ajoute ici la logique de téléchargement
    console.log(`Téléchargement de la ressource avec ID: ${id}`);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {additionalResources.map((resource) => (
        <ResourceCard key={resource.id} resource={resource} onDownload={handleDownload} />
      ))}
    </div>
  );
}
