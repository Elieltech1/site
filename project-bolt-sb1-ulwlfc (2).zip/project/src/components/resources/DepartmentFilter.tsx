import React from 'react';
import { Filter } from 'lucide-react';

interface DepartmentFilterProps {
  selectedDepartment: string;
  onDepartmentChange: (department: string) => void;
}

export function DepartmentFilter({ selectedDepartment, onDepartmentChange }: DepartmentFilterProps) {
  return (
    <div className="flex items-center space-x-4">
      <Filter className="h-5 w-5 text-gray-500" />
      <select
        value={selectedDepartment}
        onChange={(e) => onDepartmentChange(e.target.value)}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
      >
        <option value="all">Tous les départements</option>
        <option value="chimie">Chimie Industrielle</option>
        <option value="electromecanique">Électromécanique</option>
        <option value="mines">Mines</option>
        <option value="metallurgie">Métallurgie</option>
      </select>
    </div>
  );
}