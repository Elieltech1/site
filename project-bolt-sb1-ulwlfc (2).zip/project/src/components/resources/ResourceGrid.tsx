import React from 'react';
import { ResourceCard } from './ResourceCard';
import type { ResourceType } from '../../types/resource';

interface ResourceGridProps {
  resources: ResourceType[];
  onDownload: (id: string) => void;
}

export function ResourceGrid({ resources, onDownload }: ResourceGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {resources.map((resource) => (
        <ResourceCard
          key={resource.id}
          resource={resource}
          onDownload={onDownload}
        />
      ))}
    </div>
  );
}