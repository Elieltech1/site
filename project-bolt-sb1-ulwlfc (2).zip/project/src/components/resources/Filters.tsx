import React from 'react';
import { Filter } from 'lucide-react';

interface FiltersProps {
  selectedDepartment: string;
  selectedPromotion: string;
  selectedType: string;
  onDepartmentChange: (value: string) => void;
  onPromotionChange: (value: string) => void;
  onTypeChange: (value: string) => void;
}

export function Filters({
  selectedDepartment,
  selectedPromotion,
  selectedType,
  onDepartmentChange,
  onPromotionChange,
  onTypeChange
}: FiltersProps) {
  return (
    <div className="flex flex-col md:flex-row gap-4">
      <div className="flex-1">
        <label className="block text-sm font-medium text-gray-700 mb-1">Département</label>
        <select
          value={selectedDepartment}
          onChange={(e) => onDepartmentChange(e.target.value)}
          className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="all">Tous les départements</option>
          <option value="chimie">Chimie Industrielle</option>
          <option value="electromecanique">Électromécanique</option>
          <option value="mines">Mines</option>
          <option value="metallurgie">Métallurgie</option>
        </select>
      </div>

      <div className="flex-1">
        <label className="block text-sm font-medium text-gray-700 mb-1">Promotion</label>
        <select
          value={selectedPromotion}
          onChange={(e) => onPromotionChange(e.target.value)}
          className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="all">Toutes les promotions</option>
          <option value="Préparatoire">Préparatoire</option>
          <option value="Bac1">Bac 1</option>
          <option value="Bac2">Bac 2</option>
          <option value="Bac3">Bac 3</option>
        </select>
      </div>

      <div className="flex-1">
        <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
        <select
          value={selectedType}
          onChange={(e) => onTypeChange(e.target.value)}
          className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="all">Tous les types</option>
          <option value="pdf">PDF</option>
          <option value="ppt">PPT</option>
          <option value="video">Vidéo</option>
        </select>
      </div>
    </div>
  );
}