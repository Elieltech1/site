import { ArchiveType } from '../types/archive';

const generateArchives = (): ArchiveType[] => {
  const departments = ['Chimie Industrielle', 'Électromécanique', 'Mines', 'Métallurgie'];
  const supervisors = [
    'Prof. Kabamba', 'Dr. Mutombo', 'Prof. Ngoy', 'Dr. Lukusa',
    'Prof. Ilunga', 'Dr. Mwamba', 'Prof. Tshibangu', 'Dr. Kalala'
  ];
  const years = ['2020', '2021', '2022', '2023'];
  const types = ['TFC', 'TFE', 'Mémoire'] as const;
  const grades = ['Grade 2', 'Bac 3'];

  const archives: ArchiveType[] = [];

  // Chimie Industrielle
  const chimieTopics = [
    'Optimisation du processus de traitement des effluents industriels',
    'Étude de la cinétique de cristallisation des sels minéraux',
    'Analyse des procédés de séparation des hydrocarbures',
    'Développement d\'un catalyseur pour la production d\'hydrogène',
    'Valorisation des déchets plastiques par pyrolyse'
  ];

  // Électromécanique
  const electroTopics = [
    'Conception d\'un système automatisé de contrôle industriel',
    'Optimisation énergétique des moteurs électriques',
    'Étude des systèmes de transmission de puissance',
    'Maintenance prédictive des équipements industriels',
    'Développement d\'un système de surveillance en temps réel'
  ];

  // Mines
  const minesTopics = [
    'Analyse des méthodes d\'exploitation souterraine',
    'Optimisation des techniques de forage',
    'Étude géotechnique des terrains miniers',
    'Gestion environnementale des sites miniers',
    'Ventilation des galeries souterraines'
  ];

  // Métallurgie
  const metalTopics = [
    'Traitement thermique des alliages spéciaux',
    'Étude de la corrosion des métaux en milieu industriel',
    'Optimisation du processus de fonderie',
    'Caractérisation des matériaux composites',
    'Recyclage des métaux précieux'
  ];

  const generateAbstract = (title: string) => {
    return `Ce travail présente une étude approfondie sur ${title.toLowerCase()}. L'objectif principal est d'analyser et d'optimiser les processus existants tout en proposant des solutions innovantes pour améliorer l'efficacité et la durabilité.`;
  };

  let id = 1;
  departments.forEach(department => {
    const topics = department === 'Chimie Industrielle' ? chimieTopics :
                   department === 'Électromécanique' ? electroTopics :
                   department === 'Mines' ? minesTopics : metalTopics;

    // Générer 40 travaux par département
    for (let i = 0; i < 40; i++) {
      const type = types[Math.floor(Math.random() * types.length)];
      const year = years[Math.floor(Math.random() * years.length)];
      const topic = topics[Math.floor(Math.random() * topics.length)];
      const grade = grades[Math.floor(Math.random() * grades.length)];
      const baseTitle = `${topic} - Application dans l'industrie`;
      
      archives.push({
        id: id.toString(),
        title: baseTitle,
        author: `Étudiant ${id}`,
        year,
        type,
        department,
        supervisor: supervisors[Math.floor(Math.random() * supervisors.length)],
        abstract: generateAbstract(baseTitle),
        fileSize: `${Math.floor(Math.random() * 10 + 2)}MB`,
        downloadCount: Math.floor(Math.random() * 100),
        grade,
        tags: [department, type, grade, year]
      });
      id++;
    }
  });

  return archives;
};

export const archives = generateArchives();