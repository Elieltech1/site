import { ResourceType } from '../types/resource';

const departments = ['chimie', 'electromecanique', 'mines', 'metallurgie'];
const promotions = ['Préparatoire', 'Bac1', 'Bac2', 'Bac3'];
const professors = [
  'Dr. Kabamba', 'Prof. Mutombo', 'Dr. Lukusa', 'Prof. Ngoy',
  'Dr. Mwamba', 'Prof. Kalala', 'Dr. Tshibangu', 'Prof. Ilunga'
];

const coursesByDepartment = {
  chimie: [
    'Introduction à la Chimie Organique',
    'Chimie Analytique',
    'Thermodynamique Chimique',
    'Cinétique Chimique',
    'Génie des Procédés',
    'Chimie des Matériaux',
    'Chimie Industrielle',
    'Électrochimie',
    'Chimie Minérale',
    'Chimie Physique',
    'Chimie des Solutions',
    'Chimie Quantique',
    'Spectroscopie Moléculaire',
    'Chimie de Coordination',
    'Chimie des Polymères',
    'Génie Chimique',
    'Opérations Unitaires',
    'Réacteurs Chimiques',
    'Catalyse Industrielle',
    'Traitement des Eaux'
  ],
  electromecanique: [
    'Circuits Électriques',
    'Électronique de Puissance',
    'Machines Électriques',
    'Automatisation Industrielle',
    'Mécanique des Fluides',
    'Résistance des Matériaux',
    'Systèmes Embarqués',
    'Robotique',
    'Électrotechnique',
    'Maintenance Industrielle',
    'Conception Mécanique',
    'Thermodynamique Appliquée',
    'Hydraulique Industrielle',
    'Pneumatique',
    'Contrôle-Commande',
    'Électronique Numérique',
    'Microcontrôleurs',
    'Systèmes Asservis',
    'Énergies Renouvelables',
    'Réseaux Industriels'
  ],
  mines: [
    'Géologie Générale',
    'Techniques d\'Exploitation',
    'Ventilation des Mines',
    'Géotechnique',
    'Traitement des Minerais',
    'Prospection Minière',
    'Sécurité Minière',
    'Impact Environnemental',
    'Mécanique des Roches',
    'Hydrogéologie',
    'Topographie Minière',
    'Explosifs et Tirs',
    'Gisements Minéraux',
    'Économie Minière',
    'Drainage Minier',
    'Géostatistique',
    'Planification Minière',
    'Législation Minière',
    'Réhabilitation des Sites',
    'Transport Minier'
  ],
  metallurgie: [
    'Métallurgie Extractive',
    'Métallurgie des Poudres',
    'Traitements Thermiques',
    'Corrosion et Protection',
    'Métallographie',
    'Recyclage des Métaux',
    'Contrôle Qualité',
    'Procédés de Mise en Forme',
    'Sidérurgie',
    'Pyrométallurgie',
    'Hydrométallurgie',
    'Électrométallurgie',
    'Fonderie',
    'Soudage',
    'Matériaux Composites',
    'Alliages Spéciaux',
    'Caractérisation des Matériaux',
    'Transformation des Métaux',
    'Métaux Précieux',
    'Métaux Non Ferreux'
  ]
};

const chaptersByDepartment = {
  chimie: ['Théorie', 'Applications', 'Travaux Pratiques', 'Exercices'],
  electromecanique: ['Principes Fondamentaux', 'Conception', 'Maintenance', 'Études de Cas'],
  mines: ['Exploration', 'Exploitation', 'Sécurité', 'Environnement'],
  metallurgie: ['Procédés', 'Analyses', 'Contrôle', 'Innovation']
};

function generateDescription(title: string, department: string, chapter: string): string {
  return `${chapter} du cours de ${title.toLowerCase()} pour les étudiants en ${department}. Document complet avec exercices et corrections.`;
}

function generateFileSize(): string {
  const size = Math.floor(Math.random() * 45) + 5; // 5-50 MB
  return `${size} MB`;
}

export function generateResources(): ResourceType[] {
  const resources: ResourceType[] = [];
  let id = 1;

  // Pour chaque département
  departments.forEach(department => {
    const courses = coursesByDepartment[department as keyof typeof coursesByDepartment];
    const chapters = chaptersByDepartment[department as keyof typeof chaptersByDepartment];
    
    // Pour chaque cours
    courses.forEach(course => {
      // Pour chaque promotion
      promotions.forEach(promotion => {
        // Pour chaque chapitre
        chapters.forEach(chapter => {
          const resource: ResourceType = {
            id: id.toString(),
            title: `${course} - ${chapter}`,
            type: 'pdf',
            size: generateFileSize(),
            department,
            promotion,
            professor: professors[Math.floor(Math.random() * professors.length)],
            description: generateDescription(course, department, chapter)
          };

          resources.push(resource);
          id++;
        });
      });
    });
  });

  return resources;
}