import { ResourceType } from '../types/resource';
import { generateResources } from './generateResources';

export const resources: ResourceType[] = generateResources();