import React from 'react';
import { Cpu, Wrench, Zap, Link as LinkIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Electromecanique() {
  const specializations = [
    {
      title: "Électrotechnique",
      icon: <Zap className="h-8 w-8" />,
      description: "Production et distribution d'énergie électrique"
    },
    {
      title: "Automatisation",
      icon: <Cpu className="h-8 w-8" />,
      description: "Systèmes de contrôle et robotique"
    },
    {
      title: "Maintenance",
      icon: <Wrench className="h-8 w-8" />,
      description: "Gestion et maintenance des équipements"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Département d'Électromécanique</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">À propos du département</h2>
        <p className="text-gray-600 mb-6">
          Le département d'Électromécanique forme des ingénieurs polyvalents capables de concevoir,
          maintenir et optimiser des systèmes électriques et mécaniques complexes.
        </p>
        
        <h3 className="text-xl font-semibold mb-4">Nos spécialisations</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {specializations.map((spec, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="text-indigo-600 mb-4 flex justify-center">
                {spec.icon}
              </div>
              <h4 className="font-semibold mb-2">{spec.title}</h4>
              <p className="text-sm text-gray-600">{spec.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Programme d'études</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Cycle préparatoire</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-1">
              <li>Mathématiques avancées</li>
              <li>Physique générale</li>
              <li>Introduction à l'électricité</li>
              <li>Mécanique fondamentale</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Cycle de spécialisation</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-1">
              <li>Électronique de puissance</li>
              <li>Automatique et contrôle</li>
              <li>Machines électriques</li>
              <li>Systèmes hydrauliques et pneumatiques</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Laboratoires et équipements</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Laboratoire d'électronique</h3>
            <p className="text-sm text-gray-600">Équipements de mesure et de test électronique</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Atelier mécanique</h3>
            <p className="text-sm text-gray-600">Machines-outils et équipements de fabrication</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Laboratoire d'automatisme</h3>
            <p className="text-sm text-gray-600">Systèmes automatisés et robots</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-8">
        <Link 
          to="/resources?department=electromecanique"
          className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 flex items-center space-x-2"
        >
          <LinkIcon className="h-5 w-5" />
          <span>Accéder aux ressources du département</span>
        </Link>
      </div>
    </div>
  );
}