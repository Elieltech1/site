import React from 'react';
import { Hammer, Link as LinkIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Metallurgie() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Département de Métallurgie</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">À propos du département</h2>
        <p className="text-gray-600 mb-6">
          Le département de Métallurgie forme des ingénieurs spécialisés dans l'étude,
          la production et la transformation des métaux et alliages. Nos diplômés sont
          capables de gérer des processus métallurgiques complexes et d'optimiser
          la qualité des produits métalliques.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Extraction</h3>
            <p className="text-sm text-gray-600">Procédés d'extraction des métaux</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Transformation</h3>
            <p className="text-sm text-gray-600">Techniques de mise en forme</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Contrôle qualité</h3>
            <p className="text-sm text-gray-600">Analyse et tests des matériaux</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Programme d'études</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Formation théorique</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Chimie des matériaux</li>
              <li>Thermodynamique métallurgique</li>
              <li>Cristallographie</li>
              <li>Traitements thermiques</li>
              <li>Corrosion et protection</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Formation pratique</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Techniques d'analyse métallographique</li>
              <li>Procédés de fonderie</li>
              <li>Soudage et assemblage</li>
              <li>Contrôle non destructif</li>
              <li>Simulation numérique</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Débouchés professionnels</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Secteurs d'activité</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Industries minières</li>
              <li>Sidérurgie</li>
              <li>Construction mécanique</li>
              <li>Centres de recherche</li>
              <li>Bureaux d'études</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Postes types</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Ingénieur métallurgiste</li>
              <li>Responsable qualité</li>
              <li>Chef de projet R&D</li>
              <li>Expert en matériaux</li>
              <li>Consultant technique</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-8">
        <Link 
          to="/resources?department=metallurgie"
          className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 flex items-center space-x-2"
        >
          <LinkIcon className="h-5 w-5" />
          <span>Accéder aux ressources du département</span>
        </Link>
      </div>
    </div>
  );
}