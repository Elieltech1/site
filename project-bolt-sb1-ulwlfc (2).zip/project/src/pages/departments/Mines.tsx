import React from 'react';
import { Mountain, Link as LinkIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Mines() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Département des Mines et Grands Travaux</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">À propos du département</h2>
        <p className="text-gray-600 mb-6">
          Le département des Mines et Grands Travaux forme des ingénieurs spécialisés
          dans l'exploitation minière, la géologie et la gestion de grands projets
          d'infrastructure. Nos diplômés acquièrent une expertise unique dans
          l'exploitation des ressources minérales et la conduite de projets complexes.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Exploitation minière</h3>
            <p className="text-sm text-gray-600">Techniques d'extraction et planification</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Géologie</h3>
            <p className="text-sm text-gray-600">Prospection et évaluation des gisements</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Environnement</h3>
            <p className="text-sm text-gray-600">Gestion et protection environnementale</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Domaines d'expertise</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Exploitation minière</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Méthodes d'exploitation souterraine</li>
              <li>Exploitation à ciel ouvert</li>
              <li>Ventilation des mines</li>
              <li>Soutènement et stabilité</li>
              <li>Transport et logistique minière</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Géotechnique</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Mécanique des roches</li>
              <li>Stabilité des terrains</li>
              <li>Hydrogéologie</li>
              <li>Géophysique appliquée</li>
              <li>Modélisation numérique</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Équipements et laboratoires</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Laboratoire de géologie</h3>
            <p className="text-sm text-gray-600">Analyse des minerais et des roches</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Centre de simulation</h3>
            <p className="text-sm text-gray-600">Logiciels de planification minière</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Laboratoire environnemental</h3>
            <p className="text-sm text-gray-600">Analyse d'impact et traitement des eaux</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold mb-4">Opportunités professionnelles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Secteurs d'emploi</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Compagnies minières</li>
              <li>Bureaux d'études</li>
              <li>Entreprises de construction</li>
              <li>Organismes gouvernementaux</li>
              <li>Cabinets de conseil</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Postes types</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Ingénieur des mines</li>
              <li>Chef de projet</li>
              <li>Ingénieur géologue</li>
              <li>Responsable production</li>
              <li>Consultant minier</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="flex justify-center mt-8">
        <Link 
          to="/resources?department=mines"
          className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 flex items-center space-x-2"
        >
          <LinkIcon className="h-5 w-5" />
          <span>Accéder aux ressources du département</span>
        </Link>
      </div>
    </div>
  );
}