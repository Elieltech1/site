import React, { useState, useMemo } from 'react';
import { Search } from 'lucide-react';
import { archives } from '../data/archives';
import { ArchiveCard } from '../components/archives/ArchiveCard';
import { ArchiveFilters } from '../components/archives/ArchiveFilters';

export function Archives() {
  const [search, setSearch] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  const filteredArchives = useMemo(() => {
    return archives.filter(archive => {
      const matchesSearch = 
        archive.title.toLowerCase().includes(search.toLowerCase()) ||
        archive.author.toLowerCase().includes(search.toLowerCase()) ||
        archive.abstract.toLowerCase().includes(search.toLowerCase());

      const matchesDepartment = selectedDepartment === 'all' || archive.department === selectedDepartment;
      const matchesType = selectedType === 'all' || archive.type === selectedType;
      const matchesYear = selectedYear === 'all' || archive.year === selectedYear;
      const matchesGrade = selectedGrade === 'all' || archive.grade === selectedGrade;

      return matchesSearch && matchesDepartment && matchesType && matchesYear && matchesGrade;
    });
  }, [search, selectedDepartment, selectedType, selectedYear, selectedGrade]);

  const totalPages = Math.ceil(filteredArchives.length / itemsPerPage);
  const currentArchives = filteredArchives.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleDownload = (id: string) => {
    console.log(`Téléchargement du document ${id}`);
    // Implémenter la logique de téléchargement ici
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Archives Académiques</h1>
        <p className="text-gray-600">
          Consultez les travaux de fin de cycle, mémoires et autres travaux académiques
        </p>
      </div>

      <div className="space-y-6 mb-8">
        {/* Barre de recherche */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="Rechercher un travail..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Filtres */}
        <ArchiveFilters
          selectedDepartment={selectedDepartment}
          selectedType={selectedType}
          selectedYear={selectedYear}
          selectedGrade={selectedGrade}
          onDepartmentChange={setSelectedDepartment}
          onTypeChange={setSelectedType}
          onYearChange={setSelectedYear}
          onGradeChange={setSelectedGrade}
        />
      </div>

      <div className="mb-6">
        <p className="text-sm text-gray-600">
          {filteredArchives.length} travaux trouvés
        </p>
      </div>

      {/* Grille des archives */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentArchives.map((archive) => (
          <ArchiveCard
            key={archive.id}
            archive={archive}
            onDownload={handleDownload}
          />
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-8 flex justify-center">
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
            {Array.from({ length: totalPages }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentPage(index + 1)}
                className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium
                  ${currentPage === index + 1
                    ? 'z-10 bg-indigo-50 border-indigo-500 text-indigo-600'
                    : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                  }
                  ${index === 0 ? 'rounded-l-md' : ''}
                  ${index === totalPages - 1 ? 'rounded-r-md' : ''}
                `}
              >
                {index + 1}
              </button>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}