import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SearchBar } from '../components/resources/SearchBar';
import { Filters } from '../components/resources/Filters';
import { ResourceGrid } from '../components/resources/ResourceGrid';
import { resources } from '../data/resources';

export function Resources() {
  const [searchParams] = useSearchParams();
  const defaultDepartment = searchParams.get('department') || 'all';
  
  const [search, setSearch] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState(defaultDepartment);
  const [selectedPromotion, setSelectedPromotion] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  const filteredResources = useMemo(() => {
    return resources.filter(resource => {
      const matchesSearch = resource.title.toLowerCase().includes(search.toLowerCase()) ||
                          resource.professor.toLowerCase().includes(search.toLowerCase()) ||
                          resource.description.toLowerCase().includes(search.toLowerCase());
      
      const matchesDepartment = selectedDepartment === 'all' || resource.department === selectedDepartment;
      const matchesPromotion = selectedPromotion === 'all' || resource.promotion === selectedPromotion;
      const matchesType = selectedType === 'all' || resource.type === selectedType;

      return matchesSearch && matchesDepartment && matchesPromotion && matchesType;
    });
  }, [search, selectedDepartment, selectedPromotion, selectedType]);

  const totalPages = Math.ceil(filteredResources.length / itemsPerPage);
  const currentResources = filteredResources.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleDownload = (id: string) => {
    console.log(`Téléchargement du document ${id}`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Ressources Pédagogiques</h1>
        <p className="text-gray-600">
          Accédez à tous les supports de cours et documents pédagogiques
        </p>
      </div>

      <div className="space-y-6 mb-8">
        <SearchBar value={search} onChange={setSearch} />
        
        <Filters
          selectedDepartment={selectedDepartment}
          selectedPromotion={selectedPromotion}
          selectedType={selectedType}
          onDepartmentChange={setSelectedDepartment}
          onPromotionChange={setSelectedPromotion}
          onTypeChange={setSelectedType}
        />
      </div>

      <div className="mb-6">
        <p className="text-sm text-gray-600">
          {filteredResources.length} ressource(s) trouvée(s)
        </p>
      </div>

      <ResourceGrid
        resources={currentResources}
        onDownload={handleDownload}
      />

      {totalPages > 1 && (
        <div className="mt-8 flex justify-center">
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
            {Array.from({ length: totalPages }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentPage(index + 1)}
                className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium
                  ${currentPage === index + 1
                    ? 'z-10 bg-indigo-50 border-indigo-500 text-indigo-600'
                    : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                  }
                  ${index === 0 ? 'rounded-l-md' : ''}
                  ${index === totalPages - 1 ? 'rounded-r-md' : ''}
                `}
              >
                {index + 1}
              </button>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}