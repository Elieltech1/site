import React from 'react';
import { Briefcase, MapPin } from 'lucide-react';

export function Alumni() {
  const alumni = [
    {
      name: 'Jean Dupont',
      promotion: '2020',
      department: 'Chimie Industrielle',
      position: 'Ingénieur Process',
      company: 'TotalEnergies',
      location: 'Kinshasa, RDC',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300'
    },
    {
      name: 'Marie Kabongo',
      promotion: '2019',
      department: 'Électromécanique',
      position: 'Chef de Projet',
      company: 'SNEL',
      location: 'Lubumbashi, RDC',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300'
    },
    {
      name: 'Patrick Mutombo',
      promotion: '2018',
      department: 'Mines',
      position: 'Directeur Technique',
      company: 'Gécamines',
      location: 'Kolwezi, RDC',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8"> Anciens Étudiants</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {alumni.map((person, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="aspect-w-16 aspect-h-9">
              <img 
                src={person.image} 
                alt={person.name}
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{person.name}</h3>
              <p className="text-gray-600 mb-4">Promotion {person.promotion} - {person.department}</p>
              
              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <Briefcase className="w-4 h-4 mr-2" />
                  <span>{person.position} chez {person.company}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>{person.location}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}