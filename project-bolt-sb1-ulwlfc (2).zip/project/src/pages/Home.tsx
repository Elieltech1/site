import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, Download, Bell } from 'lucide-react';

export function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-indigo-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Bienvenue sur PolytechAcademia
          </h1>
          <p className="text-xl md:text-2xl mb-8">
            La plateforme éducative dédiée aux étudiants de la faculté polytechnique
          </p>
          <Link
            to="/departments"
            className="bg-white text-indigo-600 px-8 py-3 rounded-md text-lg font-semibold hover:bg-indigo-100"
          >
            Découvrir les Départements
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Nos Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<BookOpen className="h-8 w-8" />}
              title="Cours en Ligne"
              description="Accédez aux cours et ressources pédagogiques par département"
            />
            <FeatureCard
              icon={<Download className="h-8 w-8" />}
              title="Téléchargements"
              description="Téléchargez les supports de cours en PDF, PPT et vidéos"
            />
            <FeatureCard
              icon={<Users className="h-8 w-8" />}
              title="Espace Membre"
              description="Gérez votre profil et suivez vos progrès"
            />
            <FeatureCard
              icon={<Bell className="h-8 w-8" />}
              title="Notifications"
              description="Restez informé des nouveautés et mises à jour"
            />
          </div>
        </div>
      </section>

      {/* Departments Preview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Nos Départements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {departments.map((dept) => (
              <DepartmentCard key={dept.name} {...dept} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center">
      <div className="text-indigo-600 mb-4 flex justify-center">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function DepartmentCard({ name, description, image }: { name: string; description: string; image: string }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img src={image} alt={name} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <Link
          to={`/departments/${name.toLowerCase()}`}
          className="text-indigo-600 font-semibold hover:text-indigo-800"
        >
          En savoir plus →
        </Link>
      </div>
    </div>
  );
}

const departments = [
  {
    name: "Chimie Industrielle",
    description: "Formation en procédés chimiques et industriels",
    image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800"
  },
  {
    name: "Électromécanique",
    description: "Expertise en systèmes électriques et mécaniques",
    image: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=800"
  },
  {
    name: "Mines et Grands Travaux",
    description: "Spécialisation en exploitation minière",
    image: "https://images.unsplash.com/photo-1579547944212-c4f4961a8dd8?auto=format&fit=crop&w=800"
  },
  {
    name: "Métallurgie",
    description: "Étude des matériaux et procédés métallurgiques",
    image: "https://images.unsplash.com/photo-1533106497176-45ae19e68ba2?auto=format&fit=crop&w=800"
  }
];