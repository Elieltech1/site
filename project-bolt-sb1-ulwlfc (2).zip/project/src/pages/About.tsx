import React from 'react';
import { BookOpen, Users, Award, Globe, Target, Lightbulb, GraduationCap, Building, Briefcase } from 'lucide-react';
import { SectionTitle } from '../components/ui/SectionTitle';
import { StatCard } from '../components/about/StatCard';

export function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-indigo-600 to-indigo-800 text-white py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 animate-fade-in">
              Former les Leaders de Demain
            </h1>
            <p className="text-xl text-indigo-100 mb-8">
              Plus de 50 ans d'excellence dans la formation d'ingénieurs en République Démocratique du Congo
            </p>
            <div className="flex justify-center space-x-4">
              <GraduationCap className="h-16 w-16 text-indigo-200" />
            </div>
          </div>
        </div>
      </section>

      {/* Statistiques */}
      <section className="py-16 -mt-12">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <StatCard
              icon={Users}
              value="1000+"
              label="Étudiants Formés"
              description="Diplômés exerçant dans divers secteurs industriels"
            />
            <StatCard
              icon={Building}
              value="4"
              label="Départements"
              description="Spécialisations couvrant les secteurs clés de l'industrie"
            />
            <StatCard
              icon={Briefcase}
              value="85%"
              label="Insertion Professionnelle"
              description="De nos diplômés trouvent un emploi dans les 6 mois"
            />
          </div>
        </div>
      </section>

      {/* Notre Mission */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <SectionTitle
              title="Notre Mission"
              subtitle="Former des ingénieurs compétents et innovants pour le développement de la RDC"
              centered
            />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-50 p-8 rounded-lg">
                <div className="text-indigo-600 mb-4">
                  <Target className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Excellence</h3>
                <p className="text-gray-600">
                  Maintenir les plus hauts standards de qualité dans l'enseignement et la recherche
                </p>
              </div>
              <div className="bg-gray-50 p-8 rounded-lg">
                <div className="text-indigo-600 mb-4">
                  <Lightbulb className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Innovation</h3>
                <p className="text-gray-600">
                  Encourager la créativité et l'innovation dans la résolution des défis techniques
                </p>
              </div>
              <div className="bg-gray-50 p-8 rounded-lg">
                <div className="text-indigo-600 mb-4">
                  <Globe className="h-10 w-10" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Impact</h3>
                <p className="text-gray-600">
                  Contribuer activement au développement industriel et technologique du pays
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Points Forts */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <SectionTitle
              title="Nos Atouts"
              subtitle="Ce qui nous distingue dans la formation d'ingénieurs"
              centered
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="flex items-start space-x-6">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <BookOpen className="h-8 w-8 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">Programme Académique Innovant</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Formation alignée sur les standards internationaux et adaptée aux besoins de l'industrie moderne
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <Users className="h-8 w-8 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">Corps Professoral d'Elite</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Enseignants experts reconnus dans leurs domaines avec une expérience industrielle significative
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <Globe className="h-8 w-8 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">Partenariats Stratégiques</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Collaborations avec des universités et entreprises internationales de premier plan
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="bg-indigo-100 p-3 rounded-lg">
                  <Award className="h-8 w-8 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">Infrastructure Moderne</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Laboratoires équipés des dernières technologies pour une formation pratique optimale
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Histoire */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <SectionTitle
              title="Notre Histoire"
              subtitle="Plus de 50 ans d'excellence et d'innovation"
              centered
            />
            <div className="prose prose-lg mx-auto text-gray-600">
              <p className="mb-6">
                Fondée en 1970, notre institution s'est bâtie sur une vision audacieuse : devenir le fer de lance 
                de la formation d'ingénieurs en République Démocratique du Congo. Depuis, nous n'avons cessé 
                d'évoluer et d'innover pour répondre aux défis technologiques de notre temps.
              </p>
              <p className="mb-6">
                Au fil des décennies, nous avons formé plus d'un millier d'ingénieurs qui occupent aujourd'hui 
                des postes clés dans l'industrie nationale et internationale. Notre engagement envers l'excellence 
                académique et l'innovation technologique reste inébranlable.
              </p>
              <p>
                Aujourd'hui, nous sommes fiers d'être reconnus comme l'une des institutions leaders dans la 
                formation d'ingénieurs en Afrique centrale, continuant à façonner l'avenir de l'ingénierie 
                et du développement industriel en RDC.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}