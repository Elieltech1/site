import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBYmVhaIGL_CN_LoOSwPn_4MEZOyg1vEp4",
  authDomain: "polytechacad-14ed5.firebaseapp.com",
  databaseURL: "https://polytechacad-14ed5-default-rtdb.firebaseio.com",
  projectId: "polytechacad-14ed5",
  storageBucket: "polytechacad-14ed5.firebasestorage.app",
  messagingSenderId: "459838965492",
  appId: "1:459838965492:web:17e244545677bb652480a1",
  measurementId: "G-28V6JQ6PBS"
}; 


const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);