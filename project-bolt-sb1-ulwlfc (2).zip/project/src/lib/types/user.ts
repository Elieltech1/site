export interface User {
  uid: string;
  email: string;
  fullName: string;
  institution: string;
  department?: string;
  promotion?: 'Préparatoire' | 'Bac1' | 'Bac2' | 'Bac3';
  photoURL?: string;
  createdAt: string;
}

export interface UserContextType {
  user: User | null;
  loading: boolean;
  updateProfile: (data: Partial<User>) => Promise<void>;
  logout: () => Promise<void>;
}