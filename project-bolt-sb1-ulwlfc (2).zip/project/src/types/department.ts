export type Department = {
  id: string;
  name: string;
  description: string;
  icon: string;
  courses: Course[];
};

export type Course = {
  id: string;
  title: string;
  description: string;
  promotion: 'Préparatoire' | 'Bac1' | 'Bac2' | 'Bac3';
  fileUrl: string;
  fileType: 'pdf' | 'ppt' | 'video';
};