export type ArchiveType = {
  id: string;
  title: string;
  author: string;
  year: string;
  type: 'TFC' | 'TFE' | 'Mémoire';
  department: string;
  supervisor: string;
  abstract: string;
  fileSize: string;
  downloadCount: number;
  grade: string;
  tags: string[];
};