export type ResourceType = {
  id: string;
  title: string;
  type: 'pdf' | 'ppt' | 'video';
  size: string;
  department: string;
  promotion: string;
  professor: string;
  description: string;
};