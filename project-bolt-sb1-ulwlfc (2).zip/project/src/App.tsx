import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Departments } from './pages/Departments';
import { ChimieIndustrielle } from './pages/departments/ChimieIndustrielle';
import { Electromecanique } from './pages/departments/Electromecanique';
import { Metallurgie } from './pages/departments/Metallurgie';
import { Mines } from './pages/departments/Mines';
import { Resources } from './pages/Resources';
import { Archives } from './pages/Archives';
import { Alumni } from './pages/Alumni';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Profile } from './pages/Profile';
import { Contact } from './pages/Contact';

export function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/departments" element={<Departments />} />
              <Route path="/departments/chimie" element={<ChimieIndustrielle />} />
              <Route path="/departments/electromecanique" element={<Electromecanique />} />
              <Route path="/departments/metallurgie" element={<Metallurgie />} />
              <Route path="/departments/mines" element={<Mines />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/archives" element={<Archives />} />
              <Route path="/alumni" element={<Alumni />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/contact" element={<Contact />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}